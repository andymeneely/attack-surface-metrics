attack-surface-metrics
======================

Scripts for collecting metrics of the attack surface.

Pypi: https://pypi.python.org/pypi/AttackSurfaceMeter

Install using: pip install AttackSurfaceMeter
